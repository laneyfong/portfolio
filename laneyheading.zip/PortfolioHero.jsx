import React, { useEffect, useRef, useState } from "react";
import {
  motion,
  useMotionValue,
  useSpring,
  useTransform,
  animate,
} from "framer-motion";

/**
 * PortfolioHero — a hanging ID-badge hero section.
 * Stack: React + Tailwind CSS + Framer Motion.
 *
 * Setup
 * -----
 * 1) npm i framer-motion
 * 2) Load the fonts once (e.g. in index.html <head> or your global CSS):
 *
 *    <link rel="preconnect" href="https://fonts.googleapis.com" />
 *    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
 *    <link
 *      href="https://fonts.googleapis.com/css2?family=Manrope:wght@300;400;500;600;700&family=Playfair+Display:ital@1&display=swap"
 *      rel="stylesheet"
 *    />
 *
 * 3) Tailwind: works out of the box with arbitrary values used below.
 *
 * Interaction
 * -----------
 * - The card hangs from the punched hole (transformOrigin: "top center").
 * - Drag it sideways (drag="x") — on release it swings back with a decaying
 *   harmonic oscillation via Framer Motion's dragTransition bounce spring.
 * - Mouse proximity adds a soft 3D parallax tilt; hover lifts the shadow.
 * - Honors prefers-reduced-motion (skips the entrance swing).
 */

const PORTRAIT_SRC =
  "https://images.unsplash.com/photo-1501594907352-04cda38ebc29?auto=format&fit=crop&w=600&q=80";

const META = [
  ["Name", "Laney Fong"],
  ["Location", "San Francisco Bay Area"],
  ["Description", "Currently mastering HCI @ UCSC; Previously @ MyShake"],
];

const NAV = ["Work", "About", "Lab", "Resume"];

export default function PortfolioHero() {
  const wrapRef = useRef(null);

  // --- Pendulum swing -------------------------------------------------------
  // Drag drives x; rotation is derived from x so the card pivots from the hole.
  const x = useMotionValue(0);
  const rotate = useTransform(x, [-260, 260], [-24, 24], { clamp: true });

  // --- 3D proximity tilt ----------------------------------------------------
  const tiltXRaw = useMotionValue(0);
  const tiltYRaw = useMotionValue(0);
  const tiltX = useSpring(tiltXRaw, { stiffness: 140, damping: 18 });
  const tiltY = useSpring(tiltYRaw, { stiffness: 140, damping: 18 });

  const [lifted, setLifted] = useState(false);

  // Entrance: settle in with a single gentle swing (respect reduced motion).
  useEffect(() => {
    const reduce =
      typeof window !== "undefined" &&
      window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce) return;
    x.set(74);
    const controls = animate(x, 0, {
      type: "spring",
      stiffness: 90,
      damping: 6,
      mass: 1,
      restDelta: 0.02,
    });
    return () => controls.stop();
  }, [x]);

  function handlePointerMove(e) {
    const el = wrapRef.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    const dx = (e.clientX - (r.left + r.width / 2)) / (r.width / 2); // -1..1
    const dy = (e.clientY - (r.top + r.height / 2)) / (r.height / 2); // -1..1
    const clamp = (n) => Math.max(-1, Math.min(1, n));
    tiltYRaw.set(clamp(dx) * 7); // rotateY
    tiltXRaw.set(clamp(dy) * -5); // rotateX
  }

  function resetTilt() {
    tiltXRaw.set(0);
    tiltYRaw.set(0);
    setLifted(false);
  }

  return (
    <section
      className="relative min-h-screen w-full overflow-hidden"
      style={{
        background:
          "radial-gradient(120% 120% at 50% 0%, #ffffff 0%, #f6f5f2 55%, #f1efeb 100%)",
        fontFamily: "'Manrope', ui-sans-serif, system-ui, sans-serif",
      }}
      onPointerMove={handlePointerMove}
      onPointerLeave={resetTilt}
    >
      {/* Top nav */}
      <header className="relative z-10 flex items-center justify-center px-6 pt-7 sm:px-8 sm:pt-8">
        <a
          href="#"
          aria-label="Home"
          className="absolute left-6 top-6 text-2xl font-semibold leading-none sm:left-8 sm:top-7"
          style={{ color: "#2f6bff" }}
        >
          方
        </a>
        <nav
          className="flex items-center gap-1 rounded-full p-1.5"
          style={{
            background: "rgba(255,255,255,0.6)",
            border: "1px solid rgba(0,0,0,0.05)",
            backdropFilter: "blur(8px)",
            WebkitBackdropFilter: "blur(8px)",
          }}
        >
          {NAV.map((item, i) => (
            <a
              key={item}
              href="#"
              className="rounded-full px-4 py-1.5 text-[13px] tracking-tight transition-colors"
              style={{
                color: i === 0 ? "#2b2b2b" : "#9a9a9a",
                background: i === 0 ? "#ffffff" : "transparent",
                boxShadow: i === 0 ? "0 1px 2px rgba(0,0,0,0.06)" : "none",
                fontWeight: i === 0 ? 600 : 500,
              }}
            >
              {item}
            </a>
          ))}
        </nav>
      </header>

      {/* Hanging badge */}
      <div
        ref={wrapRef}
        className="flex items-start justify-center px-4 pt-12 pb-28 sm:pt-16"
        style={{ perspective: 1200 }}
      >
        <motion.div
          drag="x"
          dragConstraints={{ left: 0, right: 0 }}
          dragElastic={0.5}
          dragTransition={{ bounceStiffness: 150, bounceDamping: 6 }}
          onPointerEnter={() => setLifted(true)}
          animate={{
            boxShadow: lifted
              ? "0 50px 90px -30px rgba(20,22,30,0.28), 0 10px 30px -12px rgba(20,22,30,0.16)"
              : "0 36px 70px -28px rgba(20,22,30,0.22), 0 8px 22px -12px rgba(20,22,30,0.12)",
          }}
          transition={{ type: "spring", stiffness: 200, damping: 26 }}
          style={{
            x,
            rotate,
            rotateX: tiltX,
            rotateY: tiltY,
            transformOrigin: "top center",
            transformPerspective: 1200,
          }}
          className="relative w-[380px] max-w-[88vw] cursor-grab touch-none select-none rounded-[2rem] bg-white active:cursor-grabbing"
        >
          {/* Punched badge hole (pivot) */}
          <div className="flex justify-center pt-5">
            <div
              className="h-6 w-6 rounded-full"
              style={{
                background:
                  "radial-gradient(circle at 50% 35%, #d6d6d4 0%, #eeedeb 60%, #ffffff 100%)",
                boxShadow:
                  "inset 0 2px 4px rgba(0,0,0,0.22), inset 0 -1px 1px rgba(255,255,255,0.9), 0 1px 0 rgba(255,255,255,0.7)",
              }}
            />
          </div>

          <div className="px-9 pb-9 pt-5">
            {/* Heading */}
            <h1
              className="text-[30px] leading-tight"
              style={{ color: "#9b9b9b", fontWeight: 500, letterSpacing: "-0.02em" }}
            >
              Product Designer
            </h1>
            <p
              className="mt-1.5 text-[17px] leading-snug"
              style={{ color: "#2b2b2b", letterSpacing: "-0.01em" }}
            >
              curating intentional{" "}
              <span style={{ fontFamily: "'Playfair Display', serif", fontStyle: "italic" }}>
                human-centered
              </span>{" "}
              experiences.
            </p>

            {/* Portrait */}
            <div className="mt-7 flex justify-center">
              <div
                className="overflow-hidden rounded-[6px]"
                style={{
                  width: 196,
                  height: 224,
                  boxShadow:
                    "0 22px 40px -18px rgba(20,22,30,0.30), 0 6px 14px -8px rgba(20,22,30,0.18)",
                }}
              >
                <img
                  src={PORTRAIT_SRC}
                  alt="Laney Fong"
                  draggable={false}
                  className="h-full w-full object-cover"
                />
              </div>
            </div>

            {/* Metadata */}
            <dl className="mt-8 space-y-2.5">
              {META.map(([k, v]) => (
                <div key={k} className="flex gap-5">
                  <dt
                    className="w-[88px] shrink-0 text-[13.5px]"
                    style={{ color: "#adadad", fontWeight: 500 }}
                  >
                    {k}
                  </dt>
                  <dd className="text-[13.5px] leading-snug" style={{ color: "#2b2b2b" }}>
                    {v}
                  </dd>
                </div>
              ))}
            </dl>

            {/* CTA */}
            <div className="mt-8 flex justify-center">
              <motion.a
                href="#work"
                whileHover={{ y: -1 }}
                whileTap={{ scale: 0.97 }}
                // Let it click cleanly without initiating a card drag.
                onPointerDownCapture={(e) => e.stopPropagation()}
                className="inline-flex items-center gap-2 rounded-full px-5 py-2 text-[13.5px]"
                style={{
                  color: "#2b2b2b",
                  border: "1px solid #e6e5e2",
                  background: "#fff",
                  fontWeight: 500,
                }}
              >
                View work
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                  <path
                    d="M7 17L17 7M17 7H8M17 7V16"
                    stroke="currentColor"
                    strokeWidth="1.8"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              </motion.a>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
